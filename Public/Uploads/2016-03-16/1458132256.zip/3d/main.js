$(function () {
    $('.slider-box').unslider({
        fluid: true
    });
});